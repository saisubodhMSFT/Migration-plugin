INSERT INTO wp_bp_activity VALUES (1, 1, 'members', 'last_activity', '', '', '', 0, NULL, '2023-08-17 04:48:11', 0, 0, 0, 0);
